import React, { useState } from 'react';
import { Header } from './components/Header';
import { HelpResources } from './components/HelpResources';
import { ReviewFeedback } from './components/ReviewFeedback';
import { FinalReport } from './components/FinalReport';
import { CoachView } from './components/CoachView';
import { RoleSwitcher } from './components/RoleSwitcher';
import { Task, Status, UserRole } from './types';

function App() {
  const [userRole, setUserRole] = useState<UserRole>('hunter');
  const [status, setStatus] = useState<Status>('in-progress');
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: 'BH-001',
      toolLink: 'https://example.com/target-app',
      status: 'completed',
      reviews: [
        {
          id: 1,
          script: 'Basic XSS Test',
          scriptFile: null,
          behavior: 'Application properly escapes user input',
          vulnerabilities: 'No XSS vulnerabilities found',
          files: [],
        },
        {
          id: 2,
          script: 'SQL Injection Test',
          scriptFile: null,
          behavior: 'Input validation prevents SQL injection',
          vulnerabilities: 'No SQL injection vulnerabilities found',
          files: [],
        }
      ],
      finalReport: {
        summary: 'The application shows good security practices overall.',
        difficulty: 'medium',
      },
    },
  ]);

  const handleUpdateTaskStatus = (taskId: string, newStatus: Status) => {
    setTasks(tasks.map(task => 
      task.id === taskId ? { ...task, status: newStatus } : task
    ));
    setStatus(newStatus);
  };

  const handleSubmitReview = (taskId: string, reviewId: number, feedback: string) => {
    setTasks(tasks.map(task => {
      if (task.id === taskId) {
        return {
          ...task,
          reviews: task.reviews.map(review =>
            review.id === reviewId
              ? { 
                  ...review, 
                  reviewerFeedback: feedback, 
                  reviewedAt: new Date().toISOString(),
                  reviewerRole: userRole,
                }
              : review
          ),
        };
      }
      return task;
    }));
  };

  const handleSubmitFinalReview = (taskId: string, feedback: string) => {
    setTasks(tasks.map(task => {
      if (task.id === taskId && task.finalReport) {
        return {
          ...task,
          finalReport: {
            ...task.finalReport,
            reviewerFeedback: feedback,
            reviewedAt: new Date().toISOString(),
          },
        };
      }
      return task;
    }));
  };

  // Only show coach/admin view if user has appropriate role
  const canAccessReviewView = userRole === 'coach' || userRole === 'admin';

  return (
    <div className="min-h-screen bg-gray-50">
      <RoleSwitcher currentRole={userRole} onRoleChange={setUserRole} />
      <Header 
        taskId="BH-001"
        toolLink="https://example.com/target-app"
        status={status}
      />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {canAccessReviewView ? (
          <CoachView
            tasks={tasks}
            userRole={userRole}
            onUpdateTaskStatus={handleUpdateTaskStatus}
            onSubmitReview={handleSubmitReview}
            onSubmitFinalReview={handleSubmitFinalReview}
          />
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-8">
              <HelpResources />
            </div>
            <div className="space-y-8">
              <ReviewFeedback />
              <FinalReport />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;