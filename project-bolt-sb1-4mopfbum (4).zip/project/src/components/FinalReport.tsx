import React, { useState } from 'react';
import { Send } from 'lucide-react';

export function FinalReport() {
  const [summary, setSummary] = useState('');
  const [difficulty, setDifficulty] = useState('medium');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle final report submission
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Final Report</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium mb-1">Report Summary</label>
          <textarea
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            rows={8}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            placeholder="Provide a comprehensive summary of your findings..."
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Difficulty Rating</label>
          <select
            value={difficulty}
            onChange={(e) => setDifficulty(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="easy">Easy</option>
            <option value="medium">Medium</option>
            <option value="hard">Hard</option>
          </select>
        </div>

        <button
          type="submit"
          className="w-full flex items-center justify-center bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
        >
          <Send className="w-4 h-4 mr-2" />
          Submit Final Report
        </button>
      </form>
    </div>
  );
}