import React, { useState } from 'react';
import { Upload, Plus, X } from 'lucide-react';

interface Review {
  id: number;
  script: string;
  scriptFile: File | null;
  behavior: string;
  vulnerabilities: string;
  files: File[];
}

export function ReviewFeedback() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [currentReview, setCurrentReview] = useState<Review>({
    id: 1,
    script: '',
    scriptFile: null,
    behavior: '',
    vulnerabilities: '',
    files: [],
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      if (e.target.name === 'scriptFile') {
        setCurrentReview({ ...currentReview, scriptFile: e.target.files[0] });
      } else {
        setCurrentReview({
          ...currentReview,
          files: [...currentReview.files, ...Array.from(e.target.files)],
        });
      }
    }
  };

  const removeFile = (index: number) => {
    setCurrentReview({
      ...currentReview,
      files: currentReview.files.filter((_, i) => i !== index),
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setReviews([...reviews, currentReview]);
    setCurrentReview({
      id: currentReview.id + 1,
      script: '',
      scriptFile: null,
      behavior: '',
      vulnerabilities: '',
      files: [],
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Review & Feedback</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium mb-1">Script Name</label>
          <input
            type="text"
            value={currentReview.script}
            onChange={(e) => setCurrentReview({ ...currentReview, script: e.target.value })}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Upload Script File</label>
          <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
            <div className="space-y-1 text-center">
              <Upload className="mx-auto h-12 w-12 text-gray-400" />
              <div className="flex text-sm text-gray-600">
                <label className="relative cursor-pointer rounded-md font-medium text-blue-600 hover:text-blue-500">
                  <span>Upload a file</span>
                  <input
                    type="file"
                    name="scriptFile"
                    className="sr-only"
                    onChange={handleFileChange}
                  />
                </label>
              </div>
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Observed Behavior</label>
          <textarea
            value={currentReview.behavior}
            onChange={(e) => setCurrentReview({ ...currentReview, behavior: e.target.value })}
            rows={4}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Potential Vulnerabilities Identified</label>
          <textarea
            value={currentReview.vulnerabilities}
            onChange={(e) => setCurrentReview({ ...currentReview, vulnerabilities: e.target.value })}
            rows={4}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Supporting Files</label>
          <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
            <div className="space-y-1 text-center">
              <Plus className="mx-auto h-12 w-12 text-gray-400" />
              <div className="flex text-sm text-gray-600">
                <label className="relative cursor-pointer rounded-md font-medium text-blue-600 hover:text-blue-500">
                  <span>Add files</span>
                  <input
                    type="file"
                    multiple
                    className="sr-only"
                    onChange={handleFileChange}
                  />
                </label>
              </div>
            </div>
          </div>
          
          {currentReview.files.length > 0 && (
            <div className="mt-4 space-y-2">
              {currentReview.files.map((file, index) => (
                <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                  <span className="text-sm truncate">{file.name}</span>
                  <button
                    type="button"
                    onClick={() => removeFile(index)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
          Submit Review
        </button>
      </form>

      {reviews.length > 0 && (
        <div className="mt-8">
          <h3 className="text-lg font-medium mb-4">Previous Reviews</h3>
          <div className="space-y-4">
            {reviews.map((review) => (
              <div key={review.id} className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium">{review.script}</h4>
                <p className="mt-2 text-sm text-gray-600">{review.behavior}</p>
                <p className="mt-2 text-sm text-gray-600">{review.vulnerabilities}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {review.files.map((file, index) => (
                    <span key={index} className="text-xs bg-gray-200 px-2 py-1 rounded">
                      {file.name}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}