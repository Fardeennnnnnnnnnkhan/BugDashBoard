import React from 'react';
import { Globe, Clock, CheckCircle2 } from 'lucide-react';
import { Status } from '../types';

interface HeaderProps {
  taskId: string;
  toolLink: string;
  status: Status;
}

const statusConfig = {
  unclaimed: { color: 'bg-gray-100 text-gray-600', icon: Clock },
  'in-progress': { color: 'bg-blue-100 text-blue-600', icon: Clock },
  completed: { color: 'bg-green-100 text-green-600', icon: CheckCircle2 },
  reviewed: { color: 'bg-purple-100 text-purple-600', icon: CheckCircle2 },
  validated: { color: 'bg-emerald-100 text-emerald-600', icon: CheckCircle2 },
  returned: { color: 'bg-amber-100 text-amber-600', icon: Clock },
  approved: { color: 'bg-indigo-100 text-indigo-600', icon: CheckCircle2 },
};

export function Header({ taskId, toolLink, status }: HeaderProps) {
  const StatusIcon = statusConfig[status].icon;
  
  return (
    <div className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-xl font-semibold text-gray-900">Task ID: {taskId}</h1>
            <div className="flex items-center text-gray-600">
              <Globe className="w-4 h-4 mr-2" />
              <a href={toolLink} target="_blank" rel="noopener noreferrer" 
                 className="text-blue-600 hover:text-blue-800">
                {toolLink}
              </a>
            </div>
          </div>
          <div className={`px-3 py-1 rounded-full flex items-center ${statusConfig[status].color}`}>
            <StatusIcon className="w-4 h-4 mr-1" />
            <span className="capitalize">{status.replace('-', ' ')}</span>
          </div>
        </div>
      </div>
    </div>
  );
}