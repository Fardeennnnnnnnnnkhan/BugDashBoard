import React from 'react';
import { UserRole } from '../types';
import { Users } from 'lucide-react';

interface RoleSwitcherProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
}

export function RoleSwitcher({ currentRole, onRoleChange }: RoleSwitcherProps) {
  return (
    <div className="bg-white border-b shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
        <div className="flex items-center justify-end space-x-2">
          <Users className="w-4 h-4 text-gray-500" />
          <select
            value={currentRole}
            onChange={(e) => onRoleChange(e.target.value as UserRole)}
            className="text-sm rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="hunter">View as Hunter</option>
            <option value="coach">View as Coach</option>
            <option value="admin">View as Admin</option>
          </select>
        </div>
      </div>
    </div>
  );
}