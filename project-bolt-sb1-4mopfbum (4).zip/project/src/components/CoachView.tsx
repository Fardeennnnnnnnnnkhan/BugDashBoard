import React, { useState } from 'react';
import { CheckCircle2, RotateCcw, Eye, Send } from 'lucide-react';
import { Task, UserRole } from '../types';
import { ReviewModal } from './ReviewModal';

interface CoachViewProps {
  tasks: Task[];
  userRole: UserRole;
  onUpdateTaskStatus: (taskId: string, status: 'validated' | 'returned' | 'approved') => void;
  onSubmitReview: (taskId: string, reviewId: number, feedback: string) => void;
  onSubmitFinalReview: (taskId: string, feedback: string) => void;
}

export function CoachView({ tasks, userRole, onUpdateTaskStatus, onSubmitReview, onSubmitFinalReview }: CoachViewProps) {
  const [selectedReview, setSelectedReview] = useState<{ taskId: string; review: any } | null>(null);
  const [selectedFinalReport, setSelectedFinalReport] = useState<{ taskId: string; report: any } | null>(null);

  const completedTasks = tasks.filter(task => 
    userRole === 'admin' 
      ? task.status === 'validated'
      : task.status === 'completed'
  );

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Task Reviews</h2>
      
      <div className="space-y-6">
        {completedTasks.map((task) => (
          <div key={task.id} className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">Task ID: {task.id}</h3>
              <div className="flex items-center space-x-2">
                {userRole === 'admin' ? (
                  <button
                    onClick={() => onUpdateTaskStatus(task.id, 'approved')}
                    className="flex items-center px-3 py-1 bg-indigo-100 text-indigo-700 rounded-md hover:bg-indigo-200"
                  >
                    <Send className="w-4 h-4 mr-1" />
                    Approve for Delivery
                  </button>
                ) : (
                  <>
                    <button
                      onClick={() => onUpdateTaskStatus(task.id, 'validated')}
                      className="flex items-center px-3 py-1 bg-green-100 text-green-700 rounded-md hover:bg-green-200"
                    >
                      <CheckCircle2 className="w-4 h-4 mr-1" />
                      Validate
                    </button>
                    <button
                      onClick={() => onUpdateTaskStatus(task.id, 'returned')}
                      className="flex items-center px-3 py-1 bg-amber-100 text-amber-700 rounded-md hover:bg-amber-200"
                    >
                      <RotateCcw className="w-4 h-4 mr-1" />
                      Return
                    </button>
                  </>
                )}
              </div>
            </div>

            <div className="space-y-4">
              {task.reviews.map((review) => (
                <div key={review.id} className="flex items-center justify-between bg-gray-50 p-3 rounded-md">
                  <div>
                    <p className="font-medium">{review.script}</p>
                    {review.reviewerFeedback && (
                      <p className="text-sm text-gray-600 mt-1">
                        Previous feedback: {review.reviewerFeedback}
                      </p>
                    )}
                  </div>
                  <button
                    onClick={() => setSelectedReview({ taskId: task.id, review })}
                    className="flex items-center px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200"
                  >
                    <Eye className="w-4 h-4 mr-1" />
                    Review
                  </button>
                </div>
              ))}

              {task.finalReport && (
                <div className="bg-gray-50 p-3 rounded-md">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Final Report</p>
                      <p className="text-sm text-gray-600 mt-1">
                        Difficulty: {task.finalReport.difficulty}
                      </p>
                      {task.finalReport.reviewerFeedback && (
                        <p className="text-sm text-gray-600 mt-1">
                          Previous feedback: {task.finalReport.reviewerFeedback}
                        </p>
                      )}
                    </div>
                    <button
                      onClick={() => setSelectedFinalReport({ taskId: task.id, report: task.finalReport })}
                      className="flex items-center px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      Review
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {selectedReview && (
        <ReviewModal
          isOpen={true}
          onClose={() => setSelectedReview(null)}
          review={selectedReview.review}
          onSubmitReview={(feedback) => {
            onSubmitReview(selectedReview.taskId, selectedReview.review.id, feedback);
            setSelectedReview(null);
          }}
        />
      )}

      {selectedFinalReport && (
        <ReviewModal
          isOpen={true}
          onClose={() => setSelectedFinalReport(null)}
          review={{
            script: 'Final Report',
            behavior: selectedFinalReport.report.summary,
            vulnerabilities: `Difficulty: ${selectedFinalReport.report.difficulty}`,
          }}
          onSubmitReview={(feedback) => {
            onSubmitFinalReview(selectedFinalReport.taskId, feedback);
            setSelectedFinalReport(null);
          }}
        />
      )}
    </div>
  );
}