import React, { useState } from 'react';
import { Code2, Book, Plus, ChevronDown, ChevronUp } from 'lucide-react';

const standardScripts = [
  {
    category: 'XSS',
    scripts: [
      { name: 'Basic XSS Test', code: '<script>alert("XSS")</script>' },
      { name: 'DOM XSS Test', code: 'javascript:alert(document.domain)' },
    ],
  },
  {
    category: 'SQL Injection',
    scripts: [
      { name: 'Basic SQLi', code: "' OR '1'='1" },
      { name: 'Union Based SQLi', code: "' UNION SELECT username,password FROM users--" },
    ],
  },
];

export function HelpResources() {
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const [newScript, setNewScript] = useState({ name: '', code: '', category: '' });

  const toggleCategory = (category: string) => {
    setExpandedCategory(expandedCategory === category ? null : category);
  };

  const handleSubmitNewScript = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle new script submission
    setNewScript({ name: '', code: '', category: '' });
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Help & Resources</h2>
      
      <div className="space-y-4">
        <div className="border rounded-lg">
          <div className="p-4 border-b">
            <div className="flex items-center text-lg font-medium">
              <Code2 className="w-5 h-5 mr-2" />
              Standard Testing Scripts
            </div>
          </div>
          
          <div className="divide-y">
            {standardScripts.map((category) => (
              <div key={category.category} className="p-4">
                <button
                  onClick={() => toggleCategory(category.category)}
                  className="w-full flex items-center justify-between text-left"
                >
                  <span className="font-medium">{category.category}</span>
                  {expandedCategory === category.category ? (
                    <ChevronUp className="w-5 h-5" />
                  ) : (
                    <ChevronDown className="w-5 h-5" />
                  )}
                </button>
                
                {expandedCategory === category.category && (
                  <div className="mt-2 space-y-2">
                    {category.scripts.map((script) => (
                      <div key={script.name} className="bg-gray-50 p-3 rounded">
                        <div className="font-medium text-sm mb-1">{script.name}</div>
                        <code className="block text-sm bg-gray-100 p-2 rounded">
                          {script.code}
                        </code>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="border rounded-lg p-4">
          <div className="flex items-center text-lg font-medium mb-4">
            <Book className="w-5 h-5 mr-2" />
            Documentation & Tutorials
          </div>
          <div className="space-y-2">
            <a href="#" className="block text-blue-600 hover:underline">• Web Security Testing Guide</a>
            <a href="#" className="block text-blue-600 hover:underline">• API Security Testing Best Practices</a>
            <a href="#" className="block text-blue-600 hover:underline">• Common Vulnerability Guide</a>
          </div>
        </div>

        <div className="border rounded-lg p-4">
          <div className="flex items-center text-lg font-medium mb-4">
            <Plus className="w-5 h-5 mr-2" />
            Add New Script
          </div>
          <form onSubmit={handleSubmitNewScript} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Script Name</label>
              <input
                type="text"
                value={newScript.name}
                onChange={(e) => setNewScript({ ...newScript, name: e.target.value })}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Category</label>
              <input
                type="text"
                value={newScript.category}
                onChange={(e) => setNewScript({ ...newScript, category: e.target.value })}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Script Code</label>
              <textarea
                value={newScript.code}
                onChange={(e) => setNewScript({ ...newScript, code: e.target.value })}
                rows={4}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              Add Script
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}