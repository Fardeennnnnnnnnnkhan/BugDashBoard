import React, { useState } from 'react';
import { Play, RotateCw, Terminal } from 'lucide-react';

interface Script {
  name: string;
  code: string;
  category: string;
}

interface TestingAreaProps {
  scripts: Script[];
  onExecute: (script: Script) => void;
}

export function TestingArea({ scripts, onExecute }: TestingAreaProps) {
  const [selectedScript, setSelectedScript] = useState<Script | null>(null);
  const [output, setOutput] = useState<string>('');

  const handleExecute = () => {
    if (selectedScript) {
      setOutput(`Executing ${selectedScript.name}...\n${selectedScript.code}`);
      onExecute(selectedScript);
    }
  };

  const handleRerun = () => {
    if (selectedScript) {
      handleExecute();
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Testing Area</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Select Script</label>
          <select
            value={selectedScript?.name || ''}
            onChange={(e) => setSelectedScript(scripts.find(s => s.name === e.target.value) || null)}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="">Select a script...</option>
            {scripts.map((script) => (
              <option key={script.name} value={script.name}>
                {script.category} - {script.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex space-x-2">
          <button
            onClick={handleExecute}
            disabled={!selectedScript}
            className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Play className="w-4 h-4 mr-2" />
            Execute Script
          </button>
          
          <button
            onClick={handleRerun}
            disabled={!selectedScript}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <RotateCw className="w-4 h-4 mr-2" />
            Rerun Script
          </button>
        </div>

        <div>
          <div className="flex items-center text-sm font-medium text-gray-700 mb-2">
            <Terminal className="w-4 h-4 mr-1" />
            Output
          </div>
          <div className="bg-gray-900 text-gray-100 rounded-md p-4 font-mono text-sm whitespace-pre-wrap h-48 overflow-y-auto">
            {output || 'No output yet...'}
          </div>
        </div>
      </div>
    </div>
  );
}