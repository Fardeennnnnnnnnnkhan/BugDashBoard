export type Status = 'unclaimed' | 'in-progress' | 'completed' | 'reviewed' | 'validated' | 'returned' | 'approved';

export type UserRole = 'hunter' | 'coach' | 'admin';

export interface Review {
  id: number;
  script: string;
  scriptFile: File | null;
  behavior: string;
  vulnerabilities: string;
  files: File[];
  reviewerFeedback?: string;
  reviewerRole?: UserRole;
  reviewedAt?: string;
}

export interface Task {
  id: string;
  toolLink: string;
  status: Status;
  reviews: Review[];
  finalReport?: {
    summary: string;
    difficulty: 'easy' | 'medium' | 'hard';
    reviewerFeedback?: string;
    reviewedAt?: string;
  };
}